package com.spi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spi.model.Book;
import com.spi.service.BookService;

@RestController
public class BookController {

   @Autowired
   private BookService bookService;

   /*---Add new book---*/
   @PostMapping("/book")
   public String save(@RequestBody Book book) {
      long id = bookService.save(book);
      String mesage="New book has been saved successfully with ID "+id+"";
      return mesage;
   }

   /*---Get a book by id---*/
   @GetMapping("/book/{id}")
   public Book get(@PathVariable("id") long id) {
      Book book = bookService.get(id);
      return book;
   }

   /*---get all books---*/
   @GetMapping("/book")
   public List<Book> list() {
      List<Book> books = bookService.list();
      return books;
   }

   /*---Update a book by id---*/
   @PutMapping("/book/{id}")
   public String update(@PathVariable("id") long id, @RequestBody Book book) {
      bookService.update(id, book);
      String updationMessage="Book with id "+id+" has been successfully updated";
      return updationMessage;
   }

   /*---Delete a book by id---*/
   @DeleteMapping("/book/{id}")
   public String delete(@PathVariable("id") long id) {
      bookService.delete(id);
      String deletionMessage="Book with id "+id+" has been successfully deleted";
      return deletionMessage;
   }
}
